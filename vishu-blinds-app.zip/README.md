# Vishu Blinds and Curtains

A modern web app built using **Next.js**, **Tailwind CSS**, **TypeScript**, and **Recharts**.

## 📦 Tech Stack

- Next.js 15
- React 19
- Tailwind CSS
- TypeScript
- Recharts (for charts/graphs)
- ESLint

## 🚀 Getting Started

```bash
# Install dependencies
npm install

# Run development server
npm run dev
```

Then open [http://localhost:3000](http://localhost:3000) in your browser.

## 📁 Folder Structure

- `app/` – Main app pages (`page.tsx`, `ProductDetail.tsx`)
- `tailwind.config.js`, `postcss.config.mjs` – Tailwind setup
- `tsconfig.json` – TypeScript config
- `next.config.ts` – Next.js config
